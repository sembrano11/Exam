package com.exam.demo.service;

import java.util.List;
import com.exam.demo.model.Account;
public interface AcccountService {
	
	List<Account> getAllAccounts();
    void saveAccount(Account account);
    Account getAccountById(long id);
    void deleteAccountById(long id);

	
}
