package com.exam.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.demo.model.Account;
import com.exam.demo.repository.AccountRepository;


import java.util.List;

@Service
public class AccountServiceImpl implements AcccountService {
	
	@Autowired
	private AccountRepository accountRepository;
	
     @Override
	public List<Account> getAllAccounts(){
    	 return accountRepository.findAll();
		
	}
     @Override
     public void saveAccount(Account account) {
    	 this.accountRepository.save(account);
     }
	
	
	@Override
	public void deleteAccountById(long id) {
		this.accountRepository.deleteById(id);
		
	}
	@Override
	public Account getAccountById(long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
